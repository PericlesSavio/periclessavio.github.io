AttributeError: module 'bitsandbytes' has no attribute 'nn'


RuntimeError:
        CUDA Setup failed despite GPU being available. Please run the following command to get more information:

        python -m bitsandbyte


WARNING: No libcudart.so found! Install CUDA or the cudatoolkit package (anaconda)!  


